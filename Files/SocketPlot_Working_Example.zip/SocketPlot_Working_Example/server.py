# Copyright 2018 Elijah Jensen
# MIT standard licence
#
# This program must be run in Python 3.5 or above
# This program is an example to serve an array of floats via a websocket
#
#
import asyncio
import datetime
import random
import websockets
import numpy as np
from array import array
import math as math
import struct

#test function for data capture devices: define a signal
def makedata(dc_level):
    buffer = [0]*2048
    i=0
    while i < 2048:
        buffer[i]=dc_level+random.uniform(-0.2,0.2)+2*math.sin(0.01*i) + 1*math.sin(0.1*i) + 0.5*math.sin(i);
        i=i+1
    return buffer

########################MAIN############################

async def time(websocket, path):
    while True:
        data = makedata(0) # callback to create the data (or gather data from sensor)
        sendbytes= bytes(struct.pack('%sf' % len(data), *data)) # pack data into float array bytes
        await websocket.send(sendbytes) # tell websocket to send bytes data
        await asyncio.sleep(0.1) #sleep for 100ms


start_server = websockets.serve(time, '0.0.0.0', 4567) # listen for connections on port 4567 from all IPs

asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
