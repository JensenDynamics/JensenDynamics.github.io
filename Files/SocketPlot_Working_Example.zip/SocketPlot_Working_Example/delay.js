var interval;
function start_capture(){
  interval = setInterval(run_plot,50);
}

function stop_capture(){
  clearInterval(interval);
}
