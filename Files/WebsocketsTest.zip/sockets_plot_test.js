
var data = new Array(2048); //keep the data in an array

function get_current_ip_address() // returns the ip address of the current device
{
	return window.location.hostname;
}

function rand() {
	return Math.random();
}


//setup a new standard websocket
//this socket connects to port 4567 on the localhost
//replace the address with the IP of your choosing
var ws = new WebSocket('ws://localhost:4567/');

//  on a socket call the data will be populated in the data array and plot will be called
// if the server writes data to the socket then the data will be stored in event.data
// this function will run when the server pushes the data
ws.onmessage = function(event) {
    console.log(event.data); // print data array to console for testing

	  //data[i] = event.data; // set data as array (not working yet (server issue))

		run_plot(); // each time the server pushes data we plot it
		// to test this the data is created in this script for now
};


//simulate data for channel 0
function get_data_ch0(){
i = 0;
while(i<x_max)
{
	data[i]=  Math.sin(0.2*i)*3*rand() + Math.sin(0.1*i) + Math.sin(0.05*i);
	i = i+1;
}
}

//simulate data for channel 1
function get_data_ch1(){
i = 0;
while(i<x_max)
{
	data[i]= 2*Math.sin(0.01*i)+ 0.1*(rand()-0.5);
	i = i+1;
}
}

// this function updates the current canvas plot(s)
function run_plot(){
	get_data_ch0();
	plot("plot1");
	get_data_ch1();
	plot("plot2");
}


//plot a set of data as lines
function plot(plot_id){
var canvas1 = document.getElementById(plot_id);
if (canvas1.getContext) {
	canvas1.width  = x_axis;
	canvas1.height = y_axis*2;
	var ctx1 = canvas1.getContext("2d");
	ctx1.font = "14px sans-serif";

	ctx1.beginPath();
	ctx1.strokeStyle = '#efeb09';
	ctx1.lineWidth=2.5;

	x = 0;
	y = data[0]; // the equation
	ctx1.moveTo(offsetX(x), offsetY(y)); // set the start point at (0,Y[0])

	while (x < x_max) // loop to plot the rest of the lines
	{
		x += 1;
		y = data[x];  //set the Y values as data array values
		ctx1.lineTo(offsetX(x), offsetY(y));
	}
	ctx1.stroke();
	ctx1.closePath();
}
}

//allows zoom capability
function zoom_x_plus()
{
	if(x_max >512)
	{
x_max = x_max-256;
}else{
	x_max  = 256;
}
x_scale = x_axis / (x_max + 1);
}

function zoom_x_minus()
{
x_max = x_max+256;
x_scale = x_axis / (x_max + 1);
}
